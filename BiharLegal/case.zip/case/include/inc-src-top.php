<nav class="navbar navbar-fixed-top w3-white w3-card-4">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle w3-black" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <div class="w3-margin">
						<a href="../" class="brand"><img src="../images/3.png" style="height:40px;/* margin-left:100px; */"></a><label style="color:black;size:80px;font-weight:bold;">Yash Law Firm</label>
	</div>
    </div>
    <div class="collapse navbar-collapse " id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
  
  
   <li style="float:right;"><a href="#about"><img src="../images/top_contacts.png"></a></li>
   
   
   <li class="" style="float:left;" title="Dashbord">
<a href="http://blog.yashlawfirm.in" style="font-weight:bold;border:12 px solid black;" class=" w3-right w3-responsive">
<img src="../as.png" style="height:50px;width:50px;margin-top:-10px;border:4px solid hotpink;color:black;size:80px;" class="w3-circle w3-card-4"></a>
</li>
   
</ul>
    </div>
  </div>
</nav>
<br /><br/><br/><br /><br/><br/>












<!-- navbar-fixed-top -->
<!-- navbar-top -->
	    