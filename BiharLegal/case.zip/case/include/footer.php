 
	<!-- footer -->
	<div class="copyright">
		<div class="container">
			<p>� 2018 </p>
			<ul class="social-icons3">
				
				<li><a href="#" class="fa fa-facebook icon-border facebook"> </a></li>
				<li><a href="#" class="fa fa-twitter icon-border twitter"> </a></li>
				<li><a href="#" class="fa fa-google-plus icon-border googleplus"> </a></li>
				<li><a href="#" class="fa fa-rss icon-border rss"> </a></li>
			
			</ul>
		</div>
	</div>

