<?php

?>
 
 
		<div class="container">
       <p style="color:white;font-weight:bold;margin-top:50px;margin-left:30%;" class="w3-padding">BEST VIEW IN EACH BROWSER </p>
        </div>
 